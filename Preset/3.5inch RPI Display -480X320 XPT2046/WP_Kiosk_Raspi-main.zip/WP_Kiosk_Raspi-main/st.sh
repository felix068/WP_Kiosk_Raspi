sleep 0
startx
